
/**
 * Creates a simple game of tic tac toe.  Game is over when a player makes a line
 * of 3 of either X or O.
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class TicTacToe
{
    // instance variables - replace the example below with your own
    private static final int ROWS = 3;
    private static final int COLUMNS = 3;
    private static final int MIN = 0;
    private static final int MAX = 2;
    private String player;
    private String[][] layout;
    private enum String {E, X, O};

    /**
     * Constructor for objects of class TicTacToe
     */
    public TicTacToe()
    {
        // initialise instance variables
        layout = new String[ROWS][COLUMNS];
        player = String.X;
        resetBoard();
        displayBoard();
    }

    /**
     * Initializes the game board to Empty for each "square" of the board.
     * @param None
     * @return None
     */
    public void resetBoard()
    {
        for(int i = 0; i < ROWS; i++){
            for(int j = 0; j < COLUMNS; j++){
                layout[i][j] = String.E;
            }
        }
        player = String.X;
    }
    
    /**
     * Displays the game board the players will use to play on.
     */
    public void displayBoard(){
        System.out.println("   0 " + "  1 " + "  2");
        System.out.println();
        System.out.println("0 " + " " + layout[0][0] + " " + "|" + " " + layout[0][1] + " " + "|" + " " + layout[0][2]);
        System.out.println("  -----------");
        System.out.println("1 " + " " + layout[1][0] + " " + "|" + " " + layout[1][1] + " " + "|" + " " + layout[1][2]);
        System.out.println("  -----------");
        System.out.println("2 " + " " + layout[2][0] + " " + "|" + " " + layout[2][1] + " " + "|" + " " + layout[2][2]);
    }
    
    /**
     * Switches the player value from X to O or O to X.
     */
    public void playerTurn(){
        if(player == String.X){
            player = String.O;
        }
        else{
            player = String.X;
        }
    }
    
    /**
     * Player makes a move on the board.  The value of player will be entered in
     * what ever space they choose.  Use the numbers on the left and top to choose
     * the space you want.  Row first, then column.
     */
    public void makeMoves(int row, int col){
        int rowNum = row;
        int colNum = col;
        boolean gameEnd;
        if(row < MIN || row > MAX || col < MIN || col > MAX){
            System.out.println("Sorry, both numbers must be between 0 and 2.");
        }
        else{
            if(layout[rowNum][colNum] == String.E){
                layout[rowNum][colNum] = player;
                displayBoard();
                gameEnd = gameCheck(rowNum, colNum);
                if(gameEnd == false){
                    playerTurn();
                }
                else{
                    resetBoard();
                    displayBoard();
                }
            }
            else{
                System.out.println("Sorry, that space is already taken.");
            }
        }
    }
    
    /**
     * Checks whether the game has been won or if the game ended in a draw.
     */
    public boolean gameCheck(int rowNum, int colNum){
        int row = rowNum;
        int col = colNum;
        int spacesLeft = 0;
        boolean gameEnd = false;
        if(layout[row][0] == player && layout[row][1] == player && layout[row][2] == player){
            System.out.println(player + " has won!");
            gameEnd = true;
        }
        else if(layout[0][col] == player && layout[1][col] == player && layout[2][col] == player){
            System.out.println(player + " has won!");
            gameEnd = true;
        }
        else if((layout[0][0] == player && layout [1][1] == player && layout[2][2] == player) || (layout[0][2] == player && layout [1][1] == player && layout[2][0] == player)){
            System.out.println(player + " has won!");
            gameEnd = true;
        }
        if(gameEnd == false){
            for(int i = 0; i < ROWS; i++){
                for(int j = 0; j < COLUMNS; j++){
                    if(layout[i][j] == String.E){
                        spacesLeft++;
                    }
                }
            }
            if(spacesLeft > 0){
                System.out.println("========================");
            }
            else{
                System.out.println("The game ends in a draw!");
                gameEnd = true;
            }
        }
        return gameEnd;
    }
}
